/**
 * LaptopLegends - Main JavaScript
 * Dit bestand bevat de basis JavaScript functionaliteit.
 * Uitgebreidere functionaliteit (winkelwagen, wishlist) volgt in deelopdracht 4.
 */

// Wacht tot de DOM geladen is
document.addEventListener("DOMContentLoaded", function () {
  // Actieve navigatie-link markeren op basis van huidige pagina
  setActiveNavLink();

  // Smooth scroll voor interne links
  initSmoothScroll();

  // Console log voor debugging
  console.log("LaptopLegends website geladen!");
});
const products = {
  g14: {
    name: "ASUS ROG Zephyrus G14",
    price: 1499,
    image: "assets/images/product-1.jpg",
  },
  Razer: {
    name: "Razer Blade 16",
    price: 2999,
    image: "assets/images/product-2.jpg",
  },
  Legion: {
    name: "Lenovo Legion Pro 7i",
    price: 2499,
    image: "assets/images/product-3.jpg",
  },
  MSI: {
    name: "MSI Stealth 18",
    price: 2799,
    image: "assets/images/product-4.jpg",
  },
  acer16: {
    name: "Acer Predator Helios Neo 16",
    price: 1399,
    image: "assets/images/product-5.jpg",
  },
  HP: {
    name: "HP Omen Transcend 16",
    price: 1899,
    image: "assets/images/product-6.jpg",
  },
};
/**
 * Markeert de actieve navigatie-link op basis van de huidige URL
 */
function setActiveNavLink() {
  const currentPage = window.location.pathname.split("/").pop() || "index.html";
  const navLinks = document.querySelectorAll(".main-nav a");

  navLinks.forEach((link) => {
    const linkPage = link.getAttribute("href");

    // Verwijder 'active' class van alle links
    link.classList.remove("active");

    // Voeg 'active' class toe aan de huidige pagina link
    if (linkPage === currentPage) {
      link.classList.add("active");
    }

    // Speciale check voor productpagina's - markeer 'Shop' als actief
    if (currentPage.startsWith("product-") && linkPage === "shop.html") {
      link.classList.add("active");
    }
  });
}

/**
 * Initialiseert smooth scrolling voor interne links
 */
function initSmoothScroll() {
  const internalLinks = document.querySelectorAll('a[href^="#"]');

  internalLinks.forEach((link) => {
    link.addEventListener("click", function (e) {
      const targetId = this.getAttribute("href");

      if (targetId !== "#") {
        e.preventDefault();
        const targetElement = document.querySelector(targetId);

        if (targetElement) {
          targetElement.scrollIntoView({
            behavior: "smooth",
            block: "start",
          });
        }
      }
    });
  });
}

function addToCart(productId) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  cart.push(productId);
  localStorage.setItem("cart", JSON.stringify(cart));
  showNotification("Toegevoegd aan winkelwagen 🛒", "success");
  loadData();
}
function addToWishlist(productId) {
  let wishlist = JSON.parse(localStorage.getItem("wishlist")) || [];
  wishlist.push(productId);
  localStorage.setItem("wishlist", JSON.stringify(wishlist));

  showNotification("Toegevoegd aan wishlist ❤️", "wishlist");
}

function loadData() {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  let wishlist = JSON.parse(localStorage.getItem("wishlist")) || [];

  const cartList = document.getElementById("cart-list");
  const cartTotal = document.getElementById("cart-total");
  const wishlistList = document.getElementById("wishlist-list");

  if (cartList) {
    cartList.innerHTML = "";
    let total = 0;

    // producten groeperen
    let grouped = {};

    cart.forEach((id) => {
      grouped[id] = (grouped[id] || 0) + 1;
    });

    Object.keys(grouped).forEach((id) => {
      const product = products[id];
      if (!product) return;

      const quantity = grouped[id];
      total += product.price * quantity;

      const li = document.createElement("li");
      li.innerHTML = `
      <img src="${product.image}" width="50">
      ${product.name} 
      (x${quantity}) - €${product.price * quantity}
      <button onclick="removeOne('${id}')">➖</button>
      <button onclick="addToCart('${id}')">➕</button>
    `;

      cartList.appendChild(li);
    });

    cartTotal.textContent = "Totaal: €" + total;
  }

  if (cart.length === 0 && cartList) {
    cartList.innerHTML = "<li>Je winkelwagen is leeg</li>";
    cartTotal.textContent = "";
  }
  if (wishlist.length === 0 && wishlistList) {
    wishlistList.innerHTML = "<li>Je wishlist is leeg</li>";
  }
  if (wishlistList) {
    wishlistList.innerHTML = "";

    wishlist.forEach((id, index) => {
      const product = products[id];
      if (!product) return;

      const li = document.createElement("li");
      li.innerHTML = `
      ${product.name}
      <button onclick="removeFromWishlist(${index})">❌</button>
    `;

      wishlistList.appendChild(li);
    });
  }
}

function removeFromCart(index) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  cart.splice(index, 1);
  localStorage.setItem("cart", JSON.stringify(cart));
  loadData();
}
function removeOne(productId) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];

  const index = cart.indexOf(productId);
  if (index > -1) {
    cart.splice(index, 1);
  }

  localStorage.setItem("cart", JSON.stringify(cart));
  loadData();
}
function removeFromWishlist(index) {
  let wishlist = JSON.parse(localStorage.getItem("wishlist")) || [];
  wishlist.splice(index, 1);
  localStorage.setItem("wishlist", JSON.stringify(wishlist));
  loadData();
}

document.addEventListener("DOMContentLoaded", loadData);

function showNotification(message, type = "success") {
  const notif = document.getElementById("notification");

  notif.textContent = message;
  notif.className = "notification show " + type;

  setTimeout(() => {
    notif.classList.remove("show");
  }, 2000);
}
